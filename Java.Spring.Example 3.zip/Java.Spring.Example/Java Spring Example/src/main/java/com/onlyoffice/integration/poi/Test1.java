package com.onlyoffice.integration.poi;

import java.util.ArrayList;
import java.util.List;

import static com.onlyoffice.integration.poi.ExportUtils.UniqueCodeWordExport;

public class Test1 {


    public static void main(String[] args) throws Exception {
        String line = System.getProperty("line.separator");
        List<TicketProject> entitys = new ArrayList<>();
        entitys.add(TicketProject
                .builder()
                .evaluationCode("VvjiN63o9m")
                .evaluationProjectName("2023年×××民主测评")
                .ticketName("领导班子")
                .describe("请扫一扫二维码或在手机和电脑浏览器上输入网址进行打分")
                .guide("欢迎参加2023年×××民主测评，本次测评采用匿名方式，不收集任何个人信息，目的在于合理、真实评价有关人员的素质能力和实际工作情况。请结合现场述职及书面述职的情况，根据您日常工作中的观察、了解和所掌握的情况，做出客观评价。")
                .attention("1.请务必在限定的时间内完成评价并提交，评价通道将于2022年12月31日关闭；" +line+
                        "    2.中途因故退出，可用同一手机再次扫码进入考评系统；" +line+
                        "    3.评价一经提交无法进行修改；" +line+
                        "    4.如果您遇到任何问题，请与党委组织部联系，非常感谢您的支持！")
                .evaluationQrcode("D:/file/evaluation/1682057427848.jpg") //图片地址
                .createdDate("2023年03月09日")
                .build());

        entitys.add(TicketProject
                .builder()
                .evaluationCode("VvjiN6678o")
                .evaluationProjectName("2023年×××民主测评")
                .ticketName("领导班子")
                .describe("请扫一扫二维码或在手机和电脑浏览器上输入网址进行打分")
                .guide("欢迎参加2023年×××民主测评，本次测评采用匿名方式，不收集任何个人信息，目的在于合理、真实评价有关人员的素质能力和实际工作情况。请结合现场述职及书面述职的情况，根据您日常工作中的观察、了解和所掌握的情况，做出客观评价。")
                .attention("1.请务必在限定的时间内完成评价并提交，评价通道将于2023年3月01日关闭；" +line+
                        "    2.中途因故退出，可用同一手机再次扫码进入考评系统；" +line+
                        "    3.评价一经提交无法进行修改；" +line+
                        "    4.如果您遇到任何问题，请与党委组织部联系，非常感谢您的支持！")
                .evaluationQrcode("D:/file/evaluation/1682057427848.jpg")
                .createdDate("2023年03月11日")
                .build());

        //合并导出word文档
        UniqueCodeWordExport(entitys, null);
    }

}
