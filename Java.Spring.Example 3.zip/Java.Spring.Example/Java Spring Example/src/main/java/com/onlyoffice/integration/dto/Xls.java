package com.onlyoffice.integration.dto;

import lombok.Data;

import java.util.List;

@Data
public class Xls {
    int id;
    String createTime;
    String name;
}
