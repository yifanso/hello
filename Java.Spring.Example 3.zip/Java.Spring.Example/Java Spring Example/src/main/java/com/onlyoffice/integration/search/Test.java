package com.onlyoffice.integration.search;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;

public class Test {
    public static void main(String[] args) throws IOException {
        // 读取Excel文件
        FileInputStream inputStream = new FileInputStream(new File("/Users/songyifan/Desktop/Java.Spring.Example/Java Spring Example/documents/127.0.0.1/new.xlsx"));
        XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
        XSSFSheet sheet = workbook.getSheetAt(0); // 获取第一个工作表

        // 创建Word文档
        XWPFDocument document = new XWPFDocument();

        // 复制表格标题行到Word文档
        for (Row row : sheet) {
            XWPFParagraph paragraph = document.createParagraph();
            XWPFRun run = paragraph.createRun();
            for (Cell cell : row) {
                run.setText(cell.getStringCellValue());
                run.addBreak(); // 添加换行符
            }
        }

        // 将Word文档保存到文件
        FileOutputStream outputStream = new FileOutputStream(new File("/Users/songyifan/Desktop/Java.Spring.Example/Java Spring Example/documents/127.0.0.1/new.docx"));
        document.write(outputStream);
        document.close();
        outputStream.close();
    }
}
