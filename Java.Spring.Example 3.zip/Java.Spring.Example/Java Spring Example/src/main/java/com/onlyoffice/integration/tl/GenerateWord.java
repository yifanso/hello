package com.onlyoffice.integration.tl;

public interface GenerateWord {
    Object generateWord(LabelData data);
}
