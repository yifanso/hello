package com.onlyoffice.integration.controllers;


import cn.hutool.core.io.resource.ResourceUtil;
import com.onlyoffice.integration.dto.FileInfo;
import com.onlyoffice.integration.utils.RestResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import static com.onlyoffice.integration.poi.MyDocxUtil.searchAndReplace;
import static com.onlyoffice.integration.sheet.ReplaceSheet.replaceSheet;
import static java.lang.Thread.sleep;


@RestController
@Slf4j
@CrossOrigin("*")
public class PlaceHoldController {

    @PostMapping("/replace/excel")
    public RestResponse replaceExcelPlaceHold(@RequestBody FileInfo fileInfo) {
        RestResponse response = new RestResponse();
        try {
            //读文件
            InputStream stream = ResourceUtil.getStream("/Users/songyifan/Desktop/Java.Spring.Example/Java Spring Example/documents/127.0.0.1/" + fileInfo.getFileName());
            XSSFWorkbook workbook = new XSSFWorkbook(stream);
            String priviewFileName = fileInfo.getFileName().substring(0, fileInfo.getFileName().lastIndexOf('.')) + "(priview)"+".xlsx";
            Sheet sheet = workbook.getSheetAt(0);
            File file = new File("/Users/songyifan/Desktop/Java.Spring.Example/Java Spring Example/documents/127.0.0.1/" + priviewFileName);
            file.createNewFile();
            Map<String, Object> replaceMap = new HashMap<>();
            replaceMap.put("指标1", "100");
            replaceMap.put("指标2", "200");
            //替换内容
            replaceSheet(replaceMap, workbook, sheet, null);
            workbook.write(new FileOutputStream(file));
            response.setCode(0);
            response.setMsg("success");
            response.setData(priviewFileName);
            return response;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return response;
    }

    @PostMapping("/replace/word")
    public RestResponse replaceWordPlaceHold(@RequestBody FileInfo fileInfo) {
        RestResponse response = new RestResponse();
        try {
            Map<String, String> map = new HashMap<>();
            map.put("指标1", "true");
            map.put("指标2", "false");
            map.put("指标3", "邮储银行");
            String srcPath = "/Users/songyifan/Desktop/Java.Spring.Example/Java Spring Example/documents/127.0.0.1/" + fileInfo.getFileName();

            String priviewFileName = fileInfo.getFileName().substring(0, fileInfo.getFileName().lastIndexOf('.')) + "(priview)"+".docx";
            String destPath = "/Users/songyifan/Desktop/Java.Spring.Example/Java Spring Example/documents/127.0.0.1/" + priviewFileName;
            searchAndReplace(srcPath, destPath, map);
            sleep(1000);
            response.setCode(0);
            response.setMsg("success");
            response.setData(priviewFileName);
            return response;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return response;
    }

}
