package com.onlyoffice.integration.dto;


import lombok.Data;

@Data
public class FileInfo {
    private String fileExt;
    private String fileName;
    private String sample;
    private String uid;
}
