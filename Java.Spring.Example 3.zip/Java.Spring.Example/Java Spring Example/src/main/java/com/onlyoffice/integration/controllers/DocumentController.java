package com.onlyoffice.integration.controllers;


import cn.hutool.core.date.DateUtil;
import com.aspose.words.*;
import com.deepoove.poi.xwpf.NiceXWPFDocument;
import com.onlyoffice.integration.documentserver.managers.document.DocumentManager;
import com.onlyoffice.integration.dto.CombineFiles;
import com.onlyoffice.integration.dto.Outline;
import com.onlyoffice.integration.dto.Xls;
import com.onlyoffice.integration.entities.File;
import com.onlyoffice.integration.entities.OutlineFile;
import com.onlyoffice.integration.entities.User;
import com.onlyoffice.integration.poi.MergeDocUtils;
import com.onlyoffice.integration.repositories.FileRepository;
import com.onlyoffice.integration.repositories.OutlineRepository;
import com.onlyoffice.integration.services.FileService;
import com.onlyoffice.integration.services.UserServices;
import com.onlyoffice.integration.utils.RestResponse;
import lombok.SneakyThrows;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static cn.hutool.core.date.DatePattern.NORM_DATE_FORMAT;


@RestController
@CrossOrigin
public class DocumentController {

    @Autowired
    private FileService fileService;

    @Autowired
    private OutlineRepository outlineRepository;
    @Autowired
    private FileRepository fileRepository;
    @Autowired
    private DocumentManager documentManager;
    @Autowired
    private UserServices userService;

    @Value("${file.save.path}")
    private String path;

    @PostMapping("/doc/combine")
    public RestResponse combineDocument(@RequestBody CombineFiles combineFiles) throws Exception {
        RestResponse response = new RestResponse();
        String path0 = "/Users/songyifan/Desktop/Java.Spring.Example/Java Spring Example/documents/127.0.0.1/";
        String mergePath = path0 + combineFiles.getFileName();

        List<String> fileList = combineFiles.getFileList();
        ArrayList<java.io.File> files1 = new ArrayList<>();
        for (int i = 0; i < fileList.size(); i++) {
            files1.add(new java.io.File(path0 + fileList.get(i)));
        }
        MergeDocUtils.mergeDoc(files1, new java.io.File(mergePath));

//        List<String> fileList = combineFiles.getFileList();
//        XWPFDocument newDoc = new XWPFDocument();
//
//        for (String file : fileList) {
//            XWPFDocument doc = new XWPFDocument(new FileInputStream(path0 + file));
//            for (int i = 0; i < doc.getParagraphs().size(); i++) {
//                XWPFParagraph para = doc.getParagraphs().get(i);
//                XWPFParagraph newPara = newDoc.createParagraph();
//                newPara.createRun().setText(para.getText());
//            }
//            doc.close();
//        }
//        newDoc.write(new FileOutputStream(path0 + combineFiles.getFileName()));
//        newDoc.close();
        response.setMsg("success");
        response.setCode(0);
        return response;
    }

    @PostMapping("/create/doc/simple")
    public RestResponse createSimpleWord() {
        try {
            Document doc = new Document();
            DocumentBuilder builder = new DocumentBuilder(doc);
            createOutLine("/Users/songyifan/testdoc/" + "outline.docx");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @PostMapping("/create/xls")
    public RestResponse createXls(@RequestBody Xls xls) {
        RestResponse response = new RestResponse();
        try {
            //保存xls文档信息
            File file = new File();
            file.setCreateTime(DateUtil.format(new Date(), NORM_DATE_FORMAT));
            file.setName(xls.getName());
            file.setType("xlsx");
            fileService.saveFile(file);
            String fileName = documentManager.createOutline("xlsx",
                    false,
                    "1",
                    "");
        } catch (Exception e) {
            e.printStackTrace();
            response.setMsg("error");
            response.setCode(1);
            return response;
        }
        response.setCode(0);
        response.setMsg("Success!");
        return response;
    }

    @PostMapping("/search/xls")
    public RestResponse searchXls(@RequestBody Xls xls) {
        RestResponse response = new RestResponse();
        List<File> files = new ArrayList<>();
        try {
            //查询xls
            if (StringUtils.isEmpty(xls.getCreateTime())) {
                files = fileRepository.findByType("xlsx");
            } else {
                files = fileRepository.findByCreateTimeAndType(xls.getCreateTime(), "xlsx");
            }
            response.setData(files);
        } catch (Exception e) {
            e.printStackTrace();
            response.setMsg("error");
            response.setCode(1);
            return response;
        }
        response.setCode(0);
        response.setMsg("Success!");
        return response;
    }

    @PostMapping("/create/outline")
    public RestResponse createByItem(@RequestBody Outline outline) {
        RestResponse response = new RestResponse();
        try {
            List<String> outlineList = outline.getOutline();
            //保存主文档信息
            OutlineFile outlineInfo = new OutlineFile();
            outlineInfo.setCreateTime(DateUtil.format(new Date(), NORM_DATE_FORMAT));
            //outlineInfo.setId(outline.getId());
            outlineInfo.setName(outline.getName());
            OutlineFile ou = outlineRepository.save(outlineInfo);
            for (String item : outlineList) {
                try {
                    Optional<User> user = userService.findUserById(Integer.parseInt("1"));  // find a user by their ID
                    if (!user.isPresent()) {
                        // if the user with the specified ID doesn't exist, an error occurs
                        throw new RuntimeException("Could not fine any user with id = " + outline.getId());
                    }
                    String fileName = documentManager.createSimpleFile("docx", item + ".docx",
                            false,
                            "1",
                            user.get().getName());  // create a demo document with the sample data
                    if (fileName.isBlank() || fileName == null) {
                        throw new RuntimeException("You must have forgotten to add asset files");
                    }
                    //保存文件信息
                    File file = new File();
                    file.setParentId(ou.getId());
                    file.setCreateTime(DateUtil.format(new Date(), NORM_DATE_FORMAT));
                    file.setName(item);
                    file.setType("docx");
                    fileService.saveFile(file);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        response.setCode(0);
        response.setMsg("Success!");
        return response;
    }

    @PostMapping("/search/root")
    public RestResponse search(@RequestBody Outline outline) {
        RestResponse response = new RestResponse();
        try {
            List<OutlineFile> root;
            if (StringUtils.isEmpty(outline.getCreateTime())) {
                root = outlineRepository.findAll();
            } else {
                root = fileService.searchRoot(outline.getCreateTime());
            }
            response.setData(root);
        } catch (Exception e) {
            e.printStackTrace();
        }
        response.setCode(0);
        response.setMsg("Success!");
        return response;
    }

    @PostMapping("/search/sub")
    public RestResponse searchSub(@RequestBody Outline outline) {
        RestResponse response = new RestResponse();
        try {
            List<File> subFile = fileService.search(outline);
            response.setData(subFile);
        } catch (Exception e) {
            e.printStackTrace();
        }
        response.setCode(0);
        response.setMsg("Success!");
        return response;
    }

    @PostMapping("/search/all")
    public RestResponse findAll(@RequestBody Outline outline) {
        RestResponse response = new RestResponse();
        try {
            List<OutlineFile> outlineFiles = outlineRepository.findAll();
            response.setData(outlineFiles);
        } catch (Exception e) {
            e.printStackTrace();
        }
        response.setCode(0);
        response.setMsg("Success!");
        return response;
    }

    static void findAll(String item) {
        try {
            Document doc = new Document();
            // 添加一个段落到文档中
            Paragraph para = new Paragraph(doc);
            doc.getFirstSection().getBody().appendChild(para);
            // 添加文本到段落中
            Run run = new Run(doc, item);
            para.appendChild(run);
            // 保存文档
            doc.save("/Users/songyifan/testdoc/output.docx");
            System.out.println("Word 文件创建成功！");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SneakyThrows
    private void createOutLine(String path) {
        Document doc = new Document();
        DocumentBuilder builder = new DocumentBuilder(doc);
        builder.insertTableOfContents("\\o \"1-9\" \\h \\z \\u");//参考微软官方office文档
        builder.writeln();
        builder.getParagraphFormat().setOutlineLevel(OutlineLevel.LEVEL_1);
        builder.writeln("一级");
        builder.insertBreak(BreakType.SECTION_BREAK_NEW_PAGE);
        builder.getParagraphFormat().setOutlineLevel(OutlineLevel.LEVEL_2);
        builder.writeln("二级");
        builder.insertBreak(BreakType.SECTION_BREAK_NEW_PAGE);
        builder.getParagraphFormat().setOutlineLevel(OutlineLevel.LEVEL_3);
        builder.writeln("三级");
        builder.getParagraphFormat().setOutlineLevel(OutlineLevel.BODY_TEXT);
        builder.writeln("正文");
        doc.updateFields();
        doc.save(path);
    }
}
