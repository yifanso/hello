package com.onlyoffice.integration.services;

import com.aspose.words.*;
import java.util.HashMap;
import java.util.List;


public class ReplaceAndInsertTable implements IReplacingCallback {
    private String key;
    private HashMap<String, Object> tableMap;

    public ReplaceAndInsertTable(String key, HashMap<String, Object> tableMap) {
        this.key = key;
        this.tableMap = tableMap;
    }

    @Override
    public int replacing(ReplacingArgs e) throws Exception {
        //获取当前节点
        Node currentNode = e.getMatchNode();
        //节点拆分处理当前匹配字段
        splitRun(currentNode, e.getMatchOffset());
        //获取当前文档
        Document document = (Document) currentNode.getDocument();
        DocumentBuilder builder = new DocumentBuilder(document);
        //将光标移动到指定节点
        builder.moveTo(currentNode);

        Table table = builder.startTable();

        // 表头
        List<String> title = (List<String>) tableMap.get("title");
        List<List<String>> values = (List<List<String>>) tableMap.get("values");
        // 添加表头
        table.getRows().add(createRow(title.size(), title.toArray(new String[title.size()]), document, true));
        // 添加参数值
        for(int i = 0; i  < values.size(); i++) {
            List<String> value = values.get(i);
            if(value != null && !value.isEmpty()) {
                table.getRows().add(createRow(value.size(), value.toArray(new String[value.size()]), document, false));
            }
        }
        return ReplaceAction.SKIP;
    }

    /**
     * 创建列
     * @param value
     * @param doc
     * @return
     */
    static Cell createCell(String value, Document doc, boolean isBold) {
        Cell c1 = new Cell(doc);
        Paragraph p = new Paragraph(doc);
        Run r = new Run(doc,value);
        r.getFont().setName("微软雅黑");
        r.getFont().setBold(isBold);
        p.getParagraphFormat().setLineSpacing(12);
        p.getParagraphFormat().setAlignment(ParagraphAlignment.CENTER);
        p.appendChild(r);
        c1.appendChild(p);
        return c1;
    }

    /**
     * 创建行
     * @param columnCount
     * @param columnValues
     * @param doc
     * @return
     */
    static Row createRow(int columnCount,String[] columnValues,Document doc, boolean isBold) {
        Row r2 = new Row(doc);
//        r2.getRowFormat().setTopPadding(5d);
//        r2.getRowFormat().setBottomPadding(5d);
        for (int i = 0; i < columnCount; i++) {
            if (columnValues.length > i) {
                Cell cell = createCell(columnValues[i], doc, isBold);
                r2.getCells().add(cell);
            } else {
                Cell cell = createCell("", doc, isBold);
                r2.getCells().add(cell);
            }

        }
        return r2;
    }

    /**
     * 替换参数位置
     * @param currentNode
     * @param position
     */
    private void splitRun(Node currentNode, int position) {
        String text = currentNode.getText();
        Node newNode = currentNode.deepClone(true);
        if (text.length() >= position + this.key.length()) {
            ((Run) currentNode).setText(text.substring(position + this.key.length()));
        } else {
            int morlength = position + this.key.length() - text.length();
            ((Run) currentNode).setText("");
            Node tmpnode = currentNode;
            for (int i = 0; i < this.key.length(); i++) {
                System.out.println(i);
                tmpnode = tmpnode.getNextSibling();
                String tmptext = tmpnode.getText();
                System.out.println(tmptext);
                System.out.println(morlength);
                System.out.println("--------" + (tmptext.length() >= morlength));

                if (tmptext.length() >= morlength) {
                    ((Run) tmpnode).setText(tmptext.substring(morlength));
                    break;
                } else {
                    morlength = morlength - tmptext.length();
                    ((Run) tmpnode).setText("");
                }
            }
        }
        if (position > 0) {
            ((Run) newNode).setText(text.substring(0, position));
            currentNode.getParentNode().insertBefore(newNode, currentNode);
        }
    }
}


