package com.onlyoffice.integration.tl;

import cn.hutool.core.io.resource.ResourceUtil;
import com.deepoove.poi.XWPFTemplate;
import com.deepoove.poi.data.*;
import com.deepoove.poi.data.style.BorderStyle;
import org.apache.commons.collections4.list.TreeList;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.usermodel.*;

import java.io.*;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class PoiTlApplicationTest {

    public static void main(String[] args) throws Exception {

        // 获取 Word 模板所在路径
        String filepath = "/Users/songyifan/Desktop/Java.Spring.Example/Java Spring Example/documents/172.20.10.11/11.docx";
        // 通过 XWPFTemplate 编译文件并渲染数据到模板中
        XWPFTemplate template = XWPFTemplate.compile(filepath).render(
                new HashMap<String, Object>() {
                    {
                        put("title", "Hello, poi-tl Word模板引擎");
                        put("text", "Hello World");
                        put("author", "god23bin");
                        put("description", "这还不关注 god23bin ？再不关注我可要求你关注了！");
                        InputStream stream = ResourceUtil.getStream("/Users/songyifan/Desktop/Java.Spring.Example/Java Spring Example/documents/172.20.10.11/logo.jpg");
                        put("companyLogoUrl", Pictures.ofStream(stream, PictureType.JPEG).size(120, 120).create());
//                    put("table1", Tables.of(new String[][] {
//                            new String[] { "00", "01" },
//                            new String[] { "10", "11" }
//                    }).border(BorderStyle.DEFAULT).create());
                        RowRenderData row0 = Rows.of("姓名", "学历").textColor("FFFFFF")
                                .bgColor("4472C4").center().create();
                        RowRenderData row1 = Rows.create("李四", "博士");
                        put("table1", Tables.create(row0, row1));

                        FileInputStream inputStream = new FileInputStream(new File("/Users/songyifan/Desktop/Java.Spring.Example/Java Spring Example/documents/172.20.10.11/报表1.xlsx"));
                        Workbook workbook = new XSSFWorkbook(inputStream);  // 读取XLSX格式的文件
                        Sheet sheet = workbook.getSheetAt(0);

                        //RowRenderData tableHead = Rows.of(cell).center().bgColor("3672e5").create();

                        // 表格数据初始化
                        List<RowRenderData> renderDataList = new TreeList<>();
                        for (int i = 0; i < sheet.getPhysicalNumberOfRows(); i++) {
                            String[] rowData = new String[sheet.getRow(0).getPhysicalNumberOfCells()];
                            for (int j = 0; j < sheet.getRow(0).getPhysicalNumberOfCells(); j++) {
                                rowData[j] = sheet.getRow(i).getCell(j).getStringCellValue();
                            }
                            RowRenderData row = Rows.of(rowData).center().create();
                            renderDataList.add(row);
                        }
                        // 表格行构建
                        RowRenderData[] tableRows = new RowRenderData[sheet.getPhysicalNumberOfRows()];
                        // 添加数据行
                        for (int i = 0; i < renderDataList.size(); i++) {
                            tableRows[i] = renderDataList.get(i);
                        }
                        put("table1", Tables.of(tableRows).center().create());
                    }
                }
        );
        try {
            // 将完成数据渲染的文档写出
            template.writeAndClose(new FileOutputStream("output.docx"));
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}
