package com.onlyoffice.integration.sheet;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.io.resource.ClassPathResource;
import cn.hutool.core.io.resource.ResourceUtil;
import cn.hutool.core.util.StrUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import static org.apache.poi.ss.usermodel.CellType.NUMERIC;

public class ReplaceSheet {

    /**
     * 替换Excel模板文件内容
     *
     * @param replaceMap 文档数据
     */
    public static void replaceSheet(Map<String, Object> replaceMap, Workbook workbook, Sheet sheet, Integer endRowIndex) {
        try {
            Iterator rows = sheet.rowIterator();
            while (rows.hasNext()) {
                Row row = (Row) rows.next();
                if (row == null) {
                    continue;
                }
                int num = row.getLastCellNum();
                if (endRowIndex != null && row.getRowNum() > endRowIndex) {
                    break;
                }
                for (int i = 0; i < num; i++) {
                    Cell cell = row.getCell(i);
                    if (cell == null || cell.getCellType() == NUMERIC || cell.getStringCellValue() == null) {
                        continue;
                    }
                    String value = cell.getStringCellValue();
                    //if (StrUtil.isNotEmpty(value) && value.indexOf("${") != -1)
                    if (StrUtil.isNotEmpty(value)) {
                        cell.setCellValue(replaceValue(value, replaceMap));
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 替换内容 ${}
     *
     * @param value
     * @param replaceMap
     * @return
     */
    public static String replaceValue(String value, Map<String, Object> replaceMap) {
//        String str = value.substring(value.indexOf("${") + 2, value.indexOf('}'));
//        if (StrUtil.isEmpty(str)) {
//            return value;
//        }
//        value = value.replace("${" + str + "}", (String) replaceMap.get(str));
//        return value;
        String str = value;
        if (StrUtil.isEmpty(str)) {
            return value;
        }
        if(replaceMap.get(str) != null) {
            value = value.replace(str, (String) replaceMap.get(str));
        }
        return value;
    }

    public static void main(String[] args) {
        try {
            //读文件
            //ClassPathResource classPathResource = new ClassPathResource("/Users/songyifan/testdoc/test.xlsx");
            InputStream stream = ResourceUtil.getStream("/Users/songyifan/testdoc/test.xlsx");
            XSSFWorkbook workbook = new XSSFWorkbook(stream);
            Sheet sheet = workbook.getSheetAt(0);
            File file = new File("/Users/songyifan/testdoc/test22.xlsx");
            file.createNewFile();
            Map<String, Object> replaceMap = new HashMap<>();
            replaceMap.put("文件名称", "测试1");
            replaceMap.put("案例", "测试2");
            //替换内容
            replaceSheet(replaceMap, workbook, sheet, null);
            workbook.write(new FileOutputStream(file));

//            Sheet sheet = workbook.getSheetAt(0);
//            File file = new File("D:/easyexcel/testReplace.xlsx");
//            FileUtil.createNewFile(file);
//            Map<String, Object> replaceMap = new HashMap<>();
//            replaceMap.put("test1", "测试1");
//            replaceMap.put("test2", "测试2");
//            //替换内容
//            POIExcelUtil.replaceSheet(replaceMap, workbook, sheet, null);
//            workbook.write(new FileOutputStream(file));


        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}


