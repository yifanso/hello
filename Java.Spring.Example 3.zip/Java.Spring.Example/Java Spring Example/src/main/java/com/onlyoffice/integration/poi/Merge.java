package com.onlyoffice.integration.poi;

import java.io.File;
import java.util.ArrayList;

public class Merge {

    public static void main(String[] args) throws Exception {
        String rootPath = "/Users/songyifan/Desktop/Java.Spring.Example/Java Spring Example/documents/127.0.0.1/";
        String mergePath = rootPath+"mergeDocuments.docx";
        System.out.println(mergePath);

        ArrayList<File> files1 = new ArrayList<>();
        files1.add(new File(rootPath + "1205报告1.docx"));
        files1.add(new File(rootPath + "1205报告2.docx"));
        files1.add(new File(rootPath + "1205报告3.docx"));
        MergeDocUtils.mergeDoc(files1,new File(mergePath));
    }

}
