package com.onlyoffice.integration.poi;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

@Builder
@Data
public class TicketProject implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 序列码 VvjiN63o9m
     */
    private String evaluationCode;
    /**
     * 二维码文件地址 https://www.hjhrcloud.com/e/
     */
    private String evaluationQrcode;
    /**
     * 项目名称
     */
    private String evaluationProjectName;
    /**
     * 票种角色(领导班子、外部董事、中层)
     */
    private String ticketName;
    /**
     * 描述 请扫一扫二维码或在手机和电脑浏览器上输入网址进行打分
     */
    private String describe;

    /**
     * 简介（一页一码使用：欢迎参加2023年×××民主测评。。。）
     */
    private String information;
    /**
     * 指导语
     */
    private String guide;
    /**
     * 注意事项
     */
    private String attention;

    /**
     * 日期
     */
    private String createdDate;
}
