package com.onlyoffice.integration.dto;

import lombok.Data;

@Data
public class SheetMigration {

    private String xlsFileName;

    private String docxFileName;

    private String lable;

}
