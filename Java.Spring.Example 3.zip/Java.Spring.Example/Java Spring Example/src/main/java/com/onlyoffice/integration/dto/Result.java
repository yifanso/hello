package com.onlyoffice.integration.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 统一前后端接口
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Result implements Serializable {

    /**
     * 业务响应码
     */
    private Integer code;

    /**
     * 响应信息
     */
    private String message;

    /**
     * 响应数据
     */
    private Object data;


    /**
     * 返回成功，不带数据
     */
    public static Result ok() {
        Result resp = new Result();

        resp.setCode(0);

        return resp;
    }


    public static Result ok(Object data) {
        Result resp = new Result();

        resp.setCode(0);
        resp.setData(data);
        return resp;
    }

    /**
     * 返回失败
     * @param code 错误码
     * @param message 错误信息
     */
    public static Result fail(Integer code, String message) {
        Result resp = new Result();

        resp.setCode(code);
        resp.setMessage(message);
        return resp;
    }

    public static Result internalFail(String message) {
        Result resp = new Result();

        resp.setCode(-1);
        resp.setMessage(message);

        return resp;
    }

    public static Result operateFail(String message) {
        Result resp = new Result();

        resp.setCode(-1);
        resp.setMessage(message);

        return resp;
    }
}

