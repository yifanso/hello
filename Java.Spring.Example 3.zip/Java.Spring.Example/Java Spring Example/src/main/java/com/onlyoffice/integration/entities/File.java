package com.onlyoffice.integration.entities;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "`file`")
@Getter
@Setter
public class File {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private int id;
    private String name;
    private String type;
    private int parentId;
    private String downloadUrl;
    private String createTime;
    private String createUser;
}
