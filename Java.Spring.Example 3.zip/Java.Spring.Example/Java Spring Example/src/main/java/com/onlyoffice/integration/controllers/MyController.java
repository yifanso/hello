package com.onlyoffice.integration.controllers;

import cn.hutool.json.JSONUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.onlyoffice.integration.documentserver.models.enums.Action;
import com.onlyoffice.integration.documentserver.models.enums.Type;
import com.onlyoffice.integration.documentserver.models.filemodel.FileModel;
import com.onlyoffice.integration.dto.Result;
import com.onlyoffice.integration.entities.User;
import com.onlyoffice.integration.services.UserServices;
import com.onlyoffice.integration.services.configurers.FileConfigurer;
import com.onlyoffice.integration.services.configurers.wrappers.DefaultFileWrapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;


import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

@Controller
public class MyController {
    private String langs = "zh";
    @Autowired
    private UserServices userService;
    @Autowired
    private FileConfigurer<DefaultFileWrapper> fileConfigurer;

    @GetMapping(path = "/getTokenConfig")
    @ResponseBody
    // process request to open the editor page
    public Result getToken(@RequestParam("fileName") final String fileName,
                           @RequestParam(value = "action", required = false) final String actionParam,
                           @RequestParam(value = "type", required = false) final String typeParam,
                           @RequestParam(value = "actionLink", required = false) final String actionLink,
                           @RequestParam(value = "directUrl", required = false,
                                   defaultValue = "false") final Boolean directUrl
    ) throws JsonProcessingException {
        Action action = Action.edit;
        Type type = Type.desktop;
        Locale locale = new Locale("zh");

        if (actionParam != null) {
            action = Action.valueOf(actionParam);
        }
        if (typeParam != null) {
            type = Type.valueOf(typeParam);
        }

        List<String> langsAndKeys = Arrays.asList(langs.split("\\|"));
        for (String langAndKey : langsAndKeys) {
            String[] couple = langAndKey.split(":");
            if (couple[0].equals("zh")) {
                String[] langAndCountry = couple[0].split("-");
                locale = new Locale(langAndCountry[0], langAndCountry.length > 1 ? langAndCountry[1] : "");
            }
        }

        Optional<User> optionalUser = userService.findUserById(Integer.parseInt("1"));

        // if the user is not present, return the ONLYOFFICE start page
//        if (!optionalUser.isPresent()) {
//            return "index.html";
//        }

        User user = optionalUser.get();

        // get file model with the default file parameters
        FileModel fileModel = fileConfigurer.getFileModel(
                DefaultFileWrapper
                        .builder()
                        .fileName(fileName)
                        .type(type)
                        .lang("zh")
                        .action(action)
                        .user(user)
                        .actionData(actionLink)
                        .isEnableDirectUrl(directUrl)
                        .build()
        );
        return Result.ok(JSONUtil.toJsonStr(fileModel));
    }
}
