package com.onlyoffice.integration.dto;


import lombok.Data;

@Data
public class FileModel {

    private String model;
    private String fileHistory;
    private String docserviceApiUrl;
    private String dataInsertImage;
    private String dataCompareFile;
    private String dataMailMergeRecipients;
}
