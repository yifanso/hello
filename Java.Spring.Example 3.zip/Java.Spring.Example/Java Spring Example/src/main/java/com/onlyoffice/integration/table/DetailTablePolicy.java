package com.onlyoffice.integration.table;

import cn.hutool.core.util.ObjectUtil;
import com.deepoove.poi.policy.DynamicTableRenderPolicy;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTc;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STJc;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STVerticalJc;

import java.util.List;
import java.util.Map;

/**
 * 自定义动态表格
 * 重写render方法
 */
public class DetailTablePolicy extends DynamicTableRenderPolicy {
    @Override
    public void render(XWPFTable table, Object data) throws Exception {
        if(null == data) return;
        List<Map<String, Object>> targetRowData = (List<Map<String, Object>>) data;

        if(ObjectUtil.isNotEmpty(targetRowData) && targetRowData.size()>0){
            table.removeRow(0);
            //循环插入行数据
            for (int i = 0; i < targetRowData.size(); i++) {
                //第一行是标题行
                XWPFTableRow xwpfTableRow = table.insertNewTableRow(i);
                //循环列 row-cell
                Boolean flag = false;
                for (Map.Entry vo:targetRowData.get(i).entrySet()) {
                    XWPFTableCell cell = xwpfTableRow.createCell();
                    //单元格赋值
                    cell.setText(vo.getValue().toString());
                    //单元格文字居中
                    CTTc cttc = cell.getCTTc();
                    //文字垂直位置
                    cttc.addNewTcPr().addNewVAlign().setVal(STVerticalJc.CENTER);
                    //非标题行第一列文字居中，其他列文字居右
                    if(i == 0){
                        //文字水平位置
                        cttc.getPList().get(0).addNewPPr().addNewJc().setVal(STJc.CENTER);
                    }else{
                        //文字水平位置
                        if(flag == false){
                            cttc.getPList().get(0).addNewPPr().addNewJc().setVal(STJc.CENTER);
                        }else{
                            cttc.getPList().get(0).addNewPPr().addNewJc().setVal(STJc.RIGHT);
                        }
                    }
                    flag = true;
                }
            }
        }
    }

}
