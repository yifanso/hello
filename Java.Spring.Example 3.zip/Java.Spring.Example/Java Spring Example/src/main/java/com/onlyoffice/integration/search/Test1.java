//package com.onlyoffice.integration.search;
//
//import org.apache.poi.ss.usermodel.*;
//import org.apache.poi.xssf.usermodel.XSSFWorkbook;
//import org.apache.poi.xwpf.usermodel.*;
//import org.apache.poi.xwpf.usermodel.XWPFDocument;
//import org.apache.poi.xwpf.usermodel.XWPFParagraph;
//import org.apache.poi.xwpf.usermodel.XWPFRun;
//import org.apache.poi.xwpf.usermodel.XWPFTable;
//import org.apache.poi.xwpf.usermodel.XWPFTableRow;
//import org.apache.poi.xwpf.usermodel.XWPFTableCell;
//import org.apache.poi.xwpf.usermodel.*;
//import org.apache.poi.xwpf.usermodel.*;
//import org.apache.poi.ooxml.*;
//import org.*;
//
//import java.io.*;
//import java.util.*;
//
//public class Test1 {
//    public static void main(String[] args) throws Exception {
//        // 读取Excel文件
//        FileInputStream inputStream = new FileInputStream(new File("path/to/excel/file"));
//        Workbook workbook = new XSSFWorkbook(inputStream);
//        Sheet sheet = workbook.getSheetAt(0); // 获取第一个工作表
//
//        // 创建POI-TL的XML模板
//        XWPFDocument document = new XWPFDocument();
//        XWPFParagraph paragraph = document.createParagraph();
//        XWPFRun run = paragraph.createRun();
//        run.setText("${data}"); // 替换为要插入的数据的占位符
//
//        // 将Excel中的数据转换为POI-TL的XML模板
//        List<Cell> cells = sheet.getRow(0).getCells(); // 获取第一行的单元格数据
//        for (Cell cell : cells) {
//            String cellValue = cellToString(cell); // 将单元格数据转换为字符串
//            run = paragraph.createRun();
//            run.setText(cellValue); // 将字符串插入到XML模板中
//            run.addBreak(); // 添加换行符
//        }
//
//        // 将Word文档保存到文件
//        FileOutputStream outputStream = new FileOutputStream(new File("path/to/word/file"));
//        document.write(outputStream);
//        document.close();
//        outputStream.close();
//    }
//    private static String cellToString(Cell cell) {
//        if (cell == null) {
//            return "";
//        } else if (cell instanceof StringCell) {
//            return ((StringCell) cell).getStringCellValue();
//        } else if (cell instanceof BooleanCell) {
//            return String.valueOf(((BooleanCell) cell).getBooleanCellValue());
//        } else if (cell instanceof NumericCell) {
//            return String.valueOf(((NumericCell) cell).getNumericCellValue());
//        } else {
//            return ""; // 其他类型的单元格返回空字符串
//        }
//    }
//}
