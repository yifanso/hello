package com.onlyoffice.integration.sheet;


import com.spire.xls.Workbook;
import com.spire.xls.Worksheet;

public class ExcelToImage {
    public static void main(String[] args){

        //Create a workbook instance
        Workbook workbook = new Workbook();
        //Load a sample Excel document
        workbook.loadFromFile("/Users/songyifan/Desktop/Java.Spring.Example/Java Spring Example/documents/127.0.0.1/11.xlsx");

        //Get the first worksheet
        Worksheet sheet = workbook.getWorksheets().get(0);

        //Save the sheet to an image
        sheet.saveToImage("SheetToImage.png");
    }
}
