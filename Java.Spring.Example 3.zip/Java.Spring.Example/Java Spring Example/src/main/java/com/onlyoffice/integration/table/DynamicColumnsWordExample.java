package com.onlyoffice.integration.table;

import com.deepoove.poi.XWPFTemplate;
import com.deepoove.poi.data.RowRenderData;
import com.deepoove.poi.data.Rows;
import com.deepoove.poi.data.Tables;
import org.apache.commons.collections4.list.TreeList;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DynamicColumnsWordExample {

    public static void main(String[] args) throws IOException {
        Map<String,Object> map = new HashMap<>();


        // 标题 初始化
        List<String> titleList = new TreeList<>();
        titleList.add("序号");
        titleList.add("姓名");
        for (int i = 0; i < 10; i++) {
            titleList.add(i+1+"动态列");
        }
        String [] cell = new String[titleList.size()];
        for (int i = 0; i < titleList.size(); i++) {
            cell[i]= titleList.get(i);
        }
        // 构建 标题行
        RowRenderData tableHead = Rows.of(cell).center().bgColor("3672e5").create();

        // 表格数据 初始化
        List<String> nameList = Arrays.asList("张三","李四","王武");
        List<RowRenderData> renderDataList = new TreeList<>();
        for (int i = 0; i < nameList.size(); i++) {
            List<String> list = new TreeList<>();
            list.add(i+1+"");
            list.add(nameList.get(i));
            for (int j = 0; j < 10; j++) {
                list.add(j+1+"数据");
            }
            String [] rowData = new String[list.size()];
            for (int j = 0; j < list.size(); j++) {
                rowData[j] = list.get(j);
            }
            RowRenderData row = Rows.of(rowData).center().create();
            renderDataList.add(row);
        }
        // 表格行 构建
        RowRenderData [] tableRows = new RowRenderData[renderDataList.size()+1];
        // 添加标题行
        tableRows[0] = tableHead;
        // 添加数据行
        for (int i = 0; i < renderDataList.size(); i++) {
            tableRows[i+1] = renderDataList.get(i);
        }
        map.put("table1", Tables.of(tableRows).center().create());



        // 使用模板生成Word文档
        XWPFTemplate template = XWPFTemplate.compile("/Users/songyifan/Desktop/Java.Spring.Example/Java Spring Example/documents/172.20.10.11/11.docx").render(map);
        FileOutputStream out = new FileOutputStream("out1.docx");

        template.write(out);
        out.flush();
        out.close();
        template.close();
    }
}

