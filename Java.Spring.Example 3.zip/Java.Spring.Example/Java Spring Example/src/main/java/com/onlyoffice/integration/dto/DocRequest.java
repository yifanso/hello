package com.onlyoffice.integration.dto;

import lombok.Data;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Optional;

@Data
public class DocRequest {
    String fileExt;
    Boolean isSample;
    String uid;
}
