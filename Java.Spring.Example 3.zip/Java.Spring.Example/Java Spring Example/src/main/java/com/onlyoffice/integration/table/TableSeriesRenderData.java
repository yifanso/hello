package com.onlyoffice.integration.table;

import com.deepoove.poi.data.TextRenderData;
import com.onlyoffice.integration.tl.LabelData;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@Accessors(chain = true)
public class TableSeriesRenderData extends LabelData {

    /**
     * 表头
     */
    private TextRenderData[] header;
    /**
     * 表内容
     */
    private List<TextRenderData[]> contents;
}
