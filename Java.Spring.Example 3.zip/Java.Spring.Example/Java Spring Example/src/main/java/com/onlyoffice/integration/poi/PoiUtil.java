package com.onlyoffice.integration.poi;


//import org.apache.poi.hssf.usermodel.HSSFCell;
//import org.apache.poi.hssf.usermodel.HSSFRow;
//import org.apache.poi.hssf.usermodel.HSSFSheet;
//import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import static org.apache.poi.ss.usermodel.CellType.NUMERIC;

/**
 * Writer: loong
 */

@SuppressWarnings("unchecked")
public class PoiUtil {

    /**
     * 替换Excel模板文件内容
     *
     * @param item 文档数据
     */
    public static XSSFWorkbook replaceModel(Map<String, Object> item, InputStream ino) {
        boolean bool = true;
        try {

            //POIFSFileSystem fs  =new POIFSFileSystem(ino);
            XSSFWorkbook wb = new XSSFWorkbook(ino);
            XSSFSheet sheet = wb.getSheetAt(0);
            Iterator rows = sheet.rowIterator();
            while (rows.hasNext()) {
                XSSFRow row = (XSSFRow) rows.next();
                if (row != null) {
                    int num = row.getLastCellNum();
                    if (row.getRowNum() > 33) {
                        break;
                    }
                    for (int i = 0; i < num; i++) {
                        XSSFCell cell = row.getCell(i);
                        //设置单元格为String格式。excel是有多种类型的单元格的。
                        if (cell != null) {
                            cell.setCellType(CellType.STRING);
                        }
                        if (cell == null || cell.getStringCellValue() == null) {
                            continue;
                        }
                        String value = cell.getStringCellValue();
                        if (!"".equals(value)) {
                            if (null != item.get(value)) {
                                cell.setCellValue((String) item.get(value));
                            } else if (value.indexOf('$') != -1) {
                                cell.setCellValue(getValue(value, item));
                            }
                        } else {
                            cell.setCellValue("");
                        }
                    }
                }
            }
            // 输出文件
            return wb;
        } catch (Exception e) {
            bool = false;
            e.printStackTrace();
            return null;
        }
    }

    public static String getValue(String value, Map<String, Object> item) {

        //获取$出现的次数。
        int num = 0;
        for (int i = 0; i < value.length(); i++) {
            if ("$".equals(value.substring(i, i + 1))) {
                num++;
            }
        }
        for (int i = 0; i < num; i++) {
            String str = value.substring(value.indexOf('{') + 1, value.indexOf('}'));
            if (null == item.get(str)) {
                value = value.replace("${" + str + "}", "");
            } else {
                value = value.replace("${" + str + "}", (String) item.get(str));
            }
        }
        return value;
    }

    public static String getStr(Cell cell) {
        String str = "";
        if (cell.getCellType() == NUMERIC) {
            DecimalFormat df = new DecimalFormat("0");
            str = df.format(cell.getNumericCellValue());

//            str = cell.getNumericCellValue()+"";
//            if(str.indexOf(".")!=-1){
//                str = str.substring(0,str.indexOf(".")-1);
//            }
        } else {
            str = cell.getStringCellValue();
        }
        return str;
    }

    //    public static void main(String[] args) throws FileNotFoundException {
//        Map<String, Object> item = new HashMap<>();
//        item.put("test1", "认可");
//        item.put("test2", "136919xxxxx");
//        //InputStream ino  = ;
//        FileInputStream ino = new FileInputStream("/Users/songyifan/testdoc/test.xlsx");
    public static void main(String[] args) {
        File file = new File("/Users/songyifan/Desktop/Java.Spring.Example/Java Spring Example/documents/172.20.10.11/111.xlsx");
        FileInputStream fis = null;
        ByteArrayOutputStream baos = null;
        try {
            fis = new FileInputStream(file);
            baos = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int len;
            while ((len = fis.read(buffer)) > -1) {
                baos.write(buffer, 0, len);
            }
            byte[] fileBytes = baos.toByteArray();
            ByteArrayInputStream bais = new ByteArrayInputStream(fileBytes);
            // 可以对bais进行进一步的处理
            Map<String, Object> item = new HashMap<>();
            item.put("test1", "认可");
            item.put("test2", "136919xxxxx");
            replaceModel(item, bais);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (fis != null) {
                    fis.close();
                }
                if (baos != null) {
                    baos.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

}
