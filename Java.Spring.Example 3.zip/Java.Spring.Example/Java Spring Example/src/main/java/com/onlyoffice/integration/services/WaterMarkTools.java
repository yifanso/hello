package com.onlyoffice.integration.services;

public class WaterMarkTools {
}
