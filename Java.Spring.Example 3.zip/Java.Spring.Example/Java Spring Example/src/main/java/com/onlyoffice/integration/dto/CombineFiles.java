package com.onlyoffice.integration.dto;


import lombok.Data;

import java.util.List;

@Data
public class CombineFiles {
    private List<String> fileList;
    private String fileName;
}
