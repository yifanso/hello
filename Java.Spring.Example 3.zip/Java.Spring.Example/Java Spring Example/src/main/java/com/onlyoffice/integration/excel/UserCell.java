package com.onlyoffice.integration.excel;

import java.awt.Color;
import java.io.Serializable;

import org.apache.poi.ss.usermodel.Cell;

public class UserCell implements Serializable{

    private static final long serialVersionUID = 1L;

    private Cell cell;
    private int row;
    private int col;
    private boolean show;
    private String text="";
    private Color color=null;

    public UserCell() {
        super();
    }

    public Cell getCell() {
        return cell;
    }
    public void setCell(Cell cell) {
        this.cell = cell;
    }
    public int getRow() {
        return row;
    }
    public void setRow(int row) {
        this.row = row;
    }
    public int getCol() {
        return col;
    }
    public void setCol(int col) {
        this.col = col;
    }
    public boolean isShow() {
        return show;
    }
    public void setShow(boolean show) {
        this.show = show;
    }
    public String getText() {
        return text;
    }
    public void setText(String text) {
        this.text = text;
    }

    public Color getColor() {
        return color;
    }
    public void setColor(Color color) {
        this.color = color;
    }

    @Override
    public String toString() {
        return "UserCell [cell=" + cell + ", row=" + row + ", col=" + col
                + ", show=" + show + ", text=" + text + ", color=" + color
                + "]";
    }
}

