package com.onlyoffice.integration.sheet;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.io.resource.ClassPathResource;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Map;

public class Test {
    public static void main(String[] args) {

        try {
            //读文件
            //ClassPathResource classPathResource = new ClassPathResource("/Users/songyifan/Desktop/Java.Spring.Example/Java Spring Example/documents/172.20.10.11/111.xlsx");
            File file1 = new File("/Users/songyifan/Desktop/Java.Spring.Example/Java Spring Example/documents/172.20.10.11/111.xlsx");
            XSSFWorkbook workbook = new XSSFWorkbook(file1);
            Sheet sheet = workbook.getSheetAt(0);
            File file = new File("/Users/songyifan/testdoc/test.xlsx");
            Map<String, Object> replaceMap = new HashMap<>();
            replaceMap.put("test1", "测试1");
            replaceMap.put("test2", "测试2");
            //替换内容
            ReplaceSheet.replaceSheet(replaceMap, workbook, sheet, null);
            workbook.write(new FileOutputStream(file));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
