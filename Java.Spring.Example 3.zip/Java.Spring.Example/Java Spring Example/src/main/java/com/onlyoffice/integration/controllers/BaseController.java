package com.onlyoffice.integration.controllers;

import cn.hutool.core.date.DateUtil;
import cn.hutool.json.JSON;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.onlyoffice.integration.documentserver.callbacks.CallbackHandler;
import com.onlyoffice.integration.documentserver.managers.callback.CallbackManager;
import com.onlyoffice.integration.documentserver.managers.document.DocumentManager;
import com.onlyoffice.integration.documentserver.managers.history.HistoryManager;
import com.onlyoffice.integration.documentserver.managers.jwt.JwtManager;
import com.onlyoffice.integration.documentserver.models.enums.Action;
import com.onlyoffice.integration.documentserver.models.enums.Type;
import com.onlyoffice.integration.documentserver.models.filemodel.FileModel;
import com.onlyoffice.integration.documentserver.storage.FileStorageMutator;
import com.onlyoffice.integration.documentserver.storage.FileStoragePathBuilder;
import com.onlyoffice.integration.documentserver.util.file.FileUtility;
import com.onlyoffice.integration.documentserver.util.service.ServiceConverter;
import com.onlyoffice.integration.dto.EditParam;
import com.onlyoffice.integration.dto.FileInfo;
import com.onlyoffice.integration.dto.Mentions;
import com.onlyoffice.integration.dto.Xls;
import com.onlyoffice.integration.entities.File;
import com.onlyoffice.integration.entities.User;
import com.onlyoffice.integration.repositories.FileRepository;
import com.onlyoffice.integration.services.FileService;
import com.onlyoffice.integration.services.UserServices;
import com.onlyoffice.integration.services.configurers.FileConfigurer;
import com.onlyoffice.integration.services.configurers.wrappers.DefaultFileWrapper;
import com.onlyoffice.integration.utils.RestResponse;
import lombok.SneakyThrows;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;

import static cn.hutool.core.date.DatePattern.NORM_DATE_FORMAT;
import static com.onlyoffice.integration.documentserver.util.Constants.ANONYMOUS_USER_ID;

@RestController
@CrossOrigin("*")
public class BaseController {


    @Value("${files.docservice.header}")
    private String documentJwtHeader;

    @Value("${filesize-max}")
    private String filesizeMax;

    @Value("${files.docservice.url.site}")
    private String docserviceUrlSite;

    @Value("${files.docservice.url.command}")
    private String docserviceUrlCommand;
    @Value("${files.docservice.url.site}")
    private String docserviceSite;

    @Value("${files.docservice.url.api}")
    private String docserviceApiUrl;

    @Value("${files.docservice.languages}")
    private String langs;



    @Autowired
    private FileUtility fileUtility;
    @Autowired
    private DocumentManager documentManager;
    @Autowired
    private JwtManager jwtManager;
    @Autowired
    private FileStorageMutator storageMutator;
    @Autowired
    private FileStoragePathBuilder storagePathBuilder;
    @Autowired
    private UserServices userService;
    @Autowired
    private CallbackHandler callbackHandler;
    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private ServiceConverter serviceConverter;
    @Autowired
    private CallbackManager callbackManager;
    @Autowired
    private FileConfigurer<DefaultFileWrapper> fileConfigurer;


    @Autowired
    private HistoryManager historyManager;

    @Autowired
    private FileService fileService;

    @Autowired
    private FileRepository fileRepository;


    @PostMapping("/create/simple")
    public RestResponse create(@RequestBody FileInfo fileInfo) {
        // specify if the sample data exists or not
        RestResponse response = new RestResponse();
        Boolean sampleData = false;
        if (fileInfo.getFileExt() != null) {
            try {
                Optional<User> user = userService.findUserById(Integer.parseInt(fileInfo.getUid()));  // find a user by their ID
                if (!user.isPresent()) {
                    // if the user with the specified ID doesn't exist, an error occurs
                    throw new RuntimeException("Could not fine any user with id = " + fileInfo.getUid());
                }
                String fileName = documentManager.createSimpleFile(fileInfo.getFileExt(), fileInfo.getFileName(),
                        sampleData,
                        fileInfo.getUid(),
                        user.get().getName());  // create a demo document with the sample data
                if (fileName.isBlank() || fileName == null) {
                    throw new RuntimeException("You must have forgotten to add asset files");
                }
                //保存文件信息
                File file = new File();
                file.setCreateTime(DateUtil.format(new Date(), NORM_DATE_FORMAT));
                file.setName(fileInfo.getFileName());
                file.setType(fileInfo.getFileExt());
                fileService.saveFile(file);
                response.setCode(0);
                response.setMsg("success");
                response.setData("redirect:editor?fileName=" + URLEncoder
                        .encode(fileName, StandardCharsets.UTF_8));
                return response;  // redirect the request
            } catch (Exception ex) {
                //model.addAttribute("error", ex.getMessage());
                response.setCode(1);
                return response;
            }
        }
        return response;
    }

    @PostMapping("/search/fileInfo")
    public RestResponse searchFileInfo(@RequestBody Xls xls) {
        RestResponse response = new RestResponse();
        List<File> files = new ArrayList<>();
        try {
            //查询xls
            if(StringUtils.isEmpty(xls.getCreateTime())) {
                files = fileRepository.findByType("xls");
            } else {
                files = fileRepository.findByCreateTimeAndType(xls.getCreateTime(), "xls");
            }
            response.setData(files);
        } catch (Exception e) {
            e.printStackTrace();
            response.setMsg("error");
            response.setCode(1);
            return response;
        }
        response.setCode(0);
        response.setMsg("Success!");
        return response;
    }

    @PostMapping("/editor/param")
    // process request to open the editor page
    public RestResponse index(@RequestBody EditParam editParam, final Model model) throws JsonProcessingException {
        RestResponse response = new RestResponse();
        Action action = Action.edit;
        Type type = Type.desktop;
        Locale locale = new Locale("en");
        if (editParam.getActionParam() != null) {
            action = Action.valueOf(editParam.getActionParam());
        }
        if (editParam.getTypeParam() != null) {
            type = Type.valueOf(editParam.getTypeParam());
        }

        List<String> langsAndKeys = Arrays.asList(editParam.getLang().split("\\|"));
        for (String langAndKey : langsAndKeys) {
            String[] couple = langAndKey.split(":");
            if (couple[0].equals(editParam.getLang())) {
                String[] langAndCountry = couple[0].split("-");
                locale = new Locale(langAndCountry[0], langAndCountry.length > 1 ? langAndCountry[1] : "");
            }
        }

        Optional<User> optionalUser = userService.findUserById(Integer.parseInt("1"));

        // if the user is not present, return the ONLYOFFICE start page

        User user = optionalUser.get();

        // get file model with the default file parameters
        FileModel fileModel = fileConfigurer.getFileModel(
                DefaultFileWrapper
                        .builder()
                        .fileName(editParam.getFileName())
                        .type(type)
                        .lang(locale.toLanguageTag())
                        .action(action)
                        .user(user)
                        .actionData(null)
                        .isEnableDirectUrl(editParam.getDirectUrl())
                        .build()
        );

        // add attributes to the specified model
        // add file model with the default parameters to the original model
        model.addAttribute("model", fileModel);

        // get file history and add it to the model
        model.addAttribute("fileHistory", historyManager.getHistory(fileModel.getDocument()));

        // create the document service api URL and add it to the model
        model.addAttribute("docserviceApiUrl", docserviceSite + docserviceApiUrl);

        // get an image and add it to the model dataCompareFile  dataInsertImage  dataMailMergeRecipients
        model.addAttribute("dataInsertImage",  getInsertImage(false));

        // get a document for comparison and add it to the model
        model.addAttribute("dataCompareFile",  getCompareFile(editParam.getDirectUrl()));

        // get recipients data for mail merging and add it to the model
        model.addAttribute("dataMailMergeRecipients", getMailMerge(editParam.getDirectUrl()));
        com.onlyoffice.integration.dto.FileModel model1 = new com.onlyoffice.integration.dto.FileModel();
        // get user data for mentions and add it to the model
        model.addAttribute("usersForMentions", getUserMentions("1"));
        Map<String, Object> map = new HashMap<>();
//        map.put("model", fileModel);
//        map.put("fileHistory", historyManager.getHistory(fileModel.getDocument()));
//        map.put("docserviceApiUrl", docserviceSite + docserviceApiUrl);

        map.put("token1",  getInsertImage(false));
        map.put("token2",  getCompareFile(editParam.getDirectUrl()));
        map.put("token3",  getMailMerge(editParam.getDirectUrl()));
        map.put("usersForMentions", getUserMentions("1"));
        List<String> list = new ArrayList<>();
        list.add(getInsertImage(false));
        list.add(getCompareFile(editParam.getDirectUrl()));
        list.add(getMailMerge(editParam.getDirectUrl()));

        response.setData(list);
        response.setCode(0);
        return response;
    }

    @SneakyThrows
    private String getInsertImage(final Boolean directUrl) {  // get an image that will be inserted into the document
        Map<String, Object> dataInsertImage = new HashMap<>();
        dataInsertImage.put("fileType", "png");
        dataInsertImage.put("url", storagePathBuilder.getServerUrl(true) + "/css/img/logo.png");
        if (directUrl) {
            dataInsertImage.put("directUrl", storagePathBuilder
                    .getServerUrl(false) + "/css/img/logo.png");
        }

        // check if the document token is enabled
        if (jwtManager.tokenEnabled()) {

            // create token from the dataInsertImage object
            dataInsertImage.put("token", jwtManager.createToken(dataInsertImage));
        }

        //return objectMapper.writeValueAsString(dataInsertImage)
        //        .substring(1, objectMapper.writeValueAsString(dataInsertImage).length() - 1);
        return jwtManager.createToken(dataInsertImage);
    }

    // get a document that will be compared with the current document
    @SneakyThrows
    private String getCompareFile(final Boolean directUrl) {
        Map<String, Object> dataCompareFile = new HashMap<>();
        dataCompareFile.put("fileType", "docx");
        dataCompareFile.put("url", storagePathBuilder.getServerUrl(true) + "/assets?name=sample.docx");
        if (directUrl) {
            dataCompareFile.put("directUrl", storagePathBuilder
                    .getServerUrl(false) + "/assets?name=sample.docx");
        }

        // check if the document token is enabled
        if (jwtManager.tokenEnabled()) {

            // create token from the dataCompareFile object
            dataCompareFile.put("token", jwtManager.createToken(dataCompareFile));
        }

        //return objectMapper.writeValueAsString(dataCompareFile);
        return jwtManager.createToken(dataCompareFile);
    }

    @SneakyThrows
    private String getMailMerge(final Boolean directUrl) {
        Map<String, Object> dataMailMergeRecipients = new HashMap<>();  // get recipients data for mail merging
        dataMailMergeRecipients.put("fileType", "csv");
        dataMailMergeRecipients.put("url", storagePathBuilder.getServerUrl(true) + "/csv");
        if (directUrl) {
            dataMailMergeRecipients.put("directUrl", storagePathBuilder.getServerUrl(false) + "/csv");
        }

        // check if the document token is enabled
        if (jwtManager.tokenEnabled()) {

            // create token from the dataMailMergeRecipients object
            dataMailMergeRecipients.put("token", jwtManager.createToken(dataMailMergeRecipients));
        }

        //return objectMapper.writeValueAsString(dataMailMergeRecipients);
        return jwtManager.createToken(dataMailMergeRecipients);
    }

    private List<Mentions> getUserMentions(final String uid) {  // get user data for mentions
        List<Mentions> usersForMentions = new ArrayList<>();
        if (uid != null && !uid.equals("4")) {
            List<User> list = userService.findAll();
            for (User u : list) {
                if (u.getId() != Integer.parseInt(uid) && u.getId() != ANONYMOUS_USER_ID) {

                    // user data includes user names and emails
                    usersForMentions.add(new Mentions(u.getName(), u.getEmail()));
                }
            }
        }

        return usersForMentions;
    }


}
