package com.onlyoffice.integration.poi;

import lombok.SneakyThrows;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.util.Units;
import org.apache.poi.xwpf.usermodel.Document;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlOptions;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTBody;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.*;

/**
 * 测评文件导出工具类
 */
public class ExportUtils {
    //占位符数组
    private static String[] PLACEHOLDER = {"${evaluationProjectName}", "${ticketName}", "${guide}", "${attention}", "${evaluationCode}", "${createdDate}", "${quickMark}"};
    //图片占位符单独处理
    private static String[] PICTURE_PLACEHOLDER = {"${quickMark}"};

    private static int WIDTH = 100; //100%
    private static int HEIGHT = 100; //100%

    /**
     * 一页一码word导出
     * @param dtos 二维码数据列表
     * @param response
     */
    @SneakyThrows
    public static void UniqueCodeWordExport(List<TicketProject> dtos, HttpServletResponse response) {
        //生成文档的名称列表
        List<String> fileNameList = new ArrayList<>();
        for (TicketProject dto : dtos) {
            String filePath = "/Users/songyifan/testdoc/UniqueCodeWordTemplate.docx"; //模板地址
            InputStream fis = Thread.currentThread().getContextClassLoader().getResourceAsStream(filePath);
            XWPFDocument doc = new XWPFDocument(fis);
            Iterator<XWPFParagraph> itPara = doc.getParagraphsIterator();
            while (itPara.hasNext()) {
                XWPFParagraph paragraph = (XWPFParagraph) itPara.next();
                List<String> placeholderList = Arrays.asList(PLACEHOLDER);
                placeholderList.forEach(s->{
                    List<XWPFRun> runs=paragraph.getRuns();
                    //文字替换
                    for (int i = 0; i < runs.size(); i++) {
                        //获取字符
                        String text = runs.get(i).getText(runs.get(i).getTextPosition());
                        if (text != null && text.contains("$")) {
                            //包含占位符的字符缓存
                            StringBuilder cache = new StringBuilder(text);
                            //记录run结束的角标，开始的角标为i
                            int endIndex = 0;
                            boolean contains = text.contains("}");
                            //同一个run中是否包含完成占位符
                            if (!contains) {
                                int j = i + 1 ;
                                for (; j < runs.size(); j++) {
                                    String text1 = runs.get(j).getText(runs.get(j).getTextPosition());
                                    if (text1 == null) {
                                        continue;
                                    }
                                    cache.append(text1);
                                    if (text1.contains("}")) {
                                        endIndex = j;
                                        break;
                                    }
                                }
                            }
                            if (contains || endIndex != 0) {
                                //处理替换
                                String key = cache.toString(); //这里是完整的占位符
                                if (key.contains(s)) {
                                    if (key.contains(PICTURE_PLACEHOLDER[0])) { //替换图片
                                        InputStream in = null;

                                        String evaluationQrcode = dto.getEvaluationQrcode();
                                        String type = evaluationQrcode.substring(evaluationQrcode.lastIndexOf(".") + 1); //二维码图片后缀
                                        //创建Random类对象
                                        Random random = new Random();
                                        //产生随机数
                                        int number = random.nextInt(999) + 1;
                                        try {
                                            if (endIndex == 0) {
                                                paragraph.removeRun(endIndex); //endIndex为0时，直接删掉run
                                            }else {
                                                for (int j = endIndex; j > i; j--) {
                                                    //角标移除后，runs会同步变动，直接继续处理i就可以
                                                    paragraph.removeRun(j);
                                                }
                                            }
                                            //重新创建一个run，用来放二维码图片
                                            XWPFRun run = paragraph.createRun();

                                            in = new FileInputStream(evaluationQrcode);//设置图片路径
                                            run.addPicture(in, getPictureType(type), "quickMark" + number,
                                                    Units.toEMU(WIDTH), Units.toEMU(HEIGHT)); //图片写入
                                            break;
                                        } catch (InvalidFormatException | IOException e) {
                                            e.printStackTrace();
                                        } finally {
                                            try {
                                                if (in != null) {
                                                    in.close();
                                                }
                                            } catch (IOException e) {
                                                e.printStackTrace();
                                            }
                                        }
                                    }else { //文字替换
                                        /**
                                         * 参数0表示生成的文字是要从哪一个地方开始放置,设置文字从位置0开始
                                         * 就可以把原来的文字全部替换掉了
                                         */
                                        runs.get(i).setText(getValue(dto, s), 0);
                                        for (int j = endIndex; j > i; j--) {
                                            //角标移除后，runs会同步变动，直接继续处理i就可以
                                            paragraph.removeRun(j);
                                        }
                                        break;
                                    }

                                }
                            }
                        }
                    }
                });
            }

            String strUUID = UUID.randomUUID().toString();
            String fileName = strUUID+".docx";
            fileNameList.add(fileName);
            FileOutputStream outStream = null;
            outStream = new FileOutputStream("/Users/songyifan/testdoc/"+fileName); //单个文件保存路径
            doc.write(outStream);
            outStream.close();
        }
        //合并word
        if (fileNameList.size() > 0) {
            String mainFileName = fileNameList.get(0);
            FileInputStream fis = new FileInputStream("/Users/songyifan/testdoc/"+mainFileName);
            XWPFDocument doc = new XWPFDocument(fis);
            for (int i = 1; i < fileNameList.size(); i++) { //循环合并
                FileInputStream fisTail = new FileInputStream("/Users/songyifan/testdoc/"+fileNameList.get(i));
                XWPFDocument docTail = new XWPFDocument(fisTail);
                doc = mergeWord(doc, docTail);
            }
            //TODO 以下写文件改为使用response下载文件
            FileOutputStream outStream = null;
            outStream = new FileOutputStream("/Users/songyifan/testdoc/合并文件.docx");
            doc.write(outStream);
            outStream.close();

            //TODO 删除fileNameList列表的文件

        }
    }

    private static String getValue(TicketProject dto, String s) {
        if (s.equals("${evaluationProjectName}")) {
            return dto.getEvaluationProjectName();
        }else if (s.equals("${ticketName}")) {
            return dto.getTicketName();
        }else if (s.equals("${guide}")) {
            return dto.getGuide();
        }else if (s.equals("${attention}")) { //注意事项
            return dto.getAttention();
        }else if (s.equals("${evaluationCode}")) {
            return dto.getEvaluationCode();
        }else if (s.equals("${createdDate}")) {
            return dto.getCreatedDate();
        }else return null;
    }
    /**
     * 根据图片类型，取得对应的图片类型代码
     * @param picType
     * @return int
     */
    private static int getPictureType(String picType){
        int res = Document.PICTURE_TYPE_PICT;
        if(picType != null){
            if(picType.equalsIgnoreCase("png")){
                res = Document.PICTURE_TYPE_PNG;
            }else if(picType.equalsIgnoreCase("dib")){
                res = Document.PICTURE_TYPE_DIB;
            }else if(picType.equalsIgnoreCase("emf")){
                res = Document.PICTURE_TYPE_EMF;
            }else if(picType.equalsIgnoreCase("jpg") || picType.equalsIgnoreCase("jpeg")){
                res = Document.PICTURE_TYPE_JPEG;
            }else if(picType.equalsIgnoreCase("wmf")){
                res = Document.PICTURE_TYPE_WMF;
            }
        }
        return res;
    }

    /**
     * 将两个word文档合并
     * @param document
     * @param doucDocument2
     * @return 合并后的文档
     */
    public static XWPFDocument mergeWord(XWPFDocument document,XWPFDocument doucDocument2) {
        XWPFParagraph p = document.createParagraph();
        //设置分页符
        p.setPageBreak(true);
        CTBody src1Body = document.getDocument().getBody();
        CTBody src2Body = doucDocument2.getDocument().getBody();
//      XWPFParagraph p2 = src2Document.createParagraph();
        XmlOptions optionsOuter = new XmlOptions();
        optionsOuter.setSaveOuter();
        String appendString = src2Body.xmlText(optionsOuter);
        String srcString = src1Body.xmlText();
        String prefix = srcString.substring(0,srcString.indexOf(">")+1);
        String mainPart = srcString.substring(srcString.indexOf(">")+1,srcString.lastIndexOf("<"));
        String sufix = srcString.substring( srcString.lastIndexOf("<") );
        String addPart = appendString.substring(appendString.indexOf(">") + 1, appendString.lastIndexOf("<"));
        CTBody makeBody = null;
        try {
            makeBody = CTBody.Factory.parse(prefix+mainPart+addPart+sufix);
        } catch (XmlException e) {
            e.printStackTrace();
        }
        src1Body.set(makeBody);
        return document;
    }


}

