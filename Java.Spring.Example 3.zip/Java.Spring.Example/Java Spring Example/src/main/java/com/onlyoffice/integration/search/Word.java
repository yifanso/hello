package com.onlyoffice.integration.search;

import com.deepoove.poi.XWPFTemplate;
import com.deepoove.poi.data.RowRenderData;
import com.deepoove.poi.data.Rows;
import com.deepoove.poi.data.Tables;
import org.apache.commons.collections4.list.TreeList;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFTable;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

public class Word {

    public void createTable() {
        XWPFDocument doc = new XWPFDocument();
        XWPFTable table= doc.createTable(3, 3);//创建一个表格
    }

    public void replace() throws IOException {

        String filePath = "sample.xls";//文件路径
        XSSFWorkbook workbook = new XSSFWorkbook();//创建Excel文件(Workbook)
        XSSFSheet sheet = workbook.createSheet();//创建工作表(Sheet)
        sheet = workbook.createSheet("Test");//创建工作表(Sheet)
//        sheet.getRow()
//        FileOutputStream out = new FileOutputStream(filePath);
//        workbook.write(out);//保存Excel文件
//        XWPFTemplate template = XWPFTemplate.compile(filepath).render(
//                new HashMap<String, Object>() {
//                    {
//                        FileInputStream inputStream = new FileInputStream(new File("/Users/songyifan/Desktop/Java.Spring.Example/Java Spring Example/documents/127.0.0.1/" + migration.getXlsFileName()));
//                        Workbook workbook = new XSSFWorkbook(inputStream);  // 读取XLSX格式的文件
//                        Sheet sheet = workbook.getSheetAt(0);
//
//                        //RowRenderData tableHead = Rows.of(cell).center().bgColor("3672e5").create();
//
//                        // 表格数据初始化
//                        List<RowRenderData> renderDataList = new TreeList<>();
//                        for (int i = 0; i < sheet.getPhysicalNumberOfRows(); i++) {
//                            String[] rowData = new String[sheet.getRow(0).getPhysicalNumberOfCells()];
//                            for (int j = 0; j < sheet.getRow(0).getPhysicalNumberOfCells(); j++) {
//                                if (sheet.getRow(i) != null && sheet.getRow(i).getCell(j) != null) {
//                                    String value = sheet.getRow(i).getCell(j).getStringCellValue();
//                                    if (value != null) {
//                                        rowData[j] = value;
//                                    }
//                                }
//                            }
//                            RowRenderData row = Rows.of(rowData).center().create();
//                            renderDataList.add(row);
//                        }
//                        // 表格行构建
//                        RowRenderData[] tableRows = new RowRenderData[sheet.getPhysicalNumberOfRows()];
//                        // 添加数据行
//                        for (int i = 0; i < renderDataList.size(); i++) {
//                            tableRows[i] = renderDataList.get(i);
//                        }
//                        put(migration.getLable(), Tables.of(tableRows).center().create());
//                    }
//                }
//        );
    }


}
