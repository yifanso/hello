package com.onlyoffice.integration.repositories;

import com.onlyoffice.integration.entities.File;
import com.onlyoffice.integration.entities.Group;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;


public interface FileRepository extends JpaRepository<File, Integer> {
    List<File> findByParentId(int parentId);
    List<File> findByCreateTimeAndType(String createTime, String type);
    List<File> findByType(String type);
}
