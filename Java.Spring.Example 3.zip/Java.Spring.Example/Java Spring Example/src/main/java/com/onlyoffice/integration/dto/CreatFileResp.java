package com.onlyoffice.integration.dto;

import com.onlyoffice.integration.entities.File;
import lombok.Data;

import java.util.List;

@Data
public class CreatFileResp {

    List<File> fileInfo;


}
