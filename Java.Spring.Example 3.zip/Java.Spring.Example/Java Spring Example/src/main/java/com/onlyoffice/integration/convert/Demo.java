package com.onlyoffice.integration.convert;

import com.fasterxml.jackson.databind.exc.InvalidFormatException;

import java.io.IOException;

public class Demo {
    public static void main(String[] args) throws IOException, InvalidFormatException {
        String s = null;
        try {
            s = DrawFromExcel.excelToImage("/Users/songyifan/Desktop/Java.Spring.Example/Java Spring Example/11.xlsx", "/Users/songyifan/Desktop/Java.Spring.Example/Java Spring Example");
        } catch (org.apache.poi.openxml4j.exceptions.InvalidFormatException e) {
            throw new RuntimeException(e);
        }
        System.out.println(s);
    }
}

