package com.onlyoffice.integration.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestParam;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class EditParam {
    private String fileName;
    private String actionParam;
    private String typeParam;
    private String actionLink;
    private Boolean directUrl;
    private String uid;
    private String lang;
}
