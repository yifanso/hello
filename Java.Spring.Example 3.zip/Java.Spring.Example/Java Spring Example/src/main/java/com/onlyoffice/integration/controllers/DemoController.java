package com.onlyoffice.integration.controllers;

import com.aspose.words.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.onlyoffice.integration.documentserver.callbacks.CallbackHandler;
import com.onlyoffice.integration.documentserver.managers.callback.CallbackManager;
import com.onlyoffice.integration.documentserver.managers.document.DocumentManager;
import com.onlyoffice.integration.documentserver.managers.jwt.JwtManager;
import com.onlyoffice.integration.documentserver.storage.FileStorageMutator;
import com.onlyoffice.integration.documentserver.storage.FileStoragePathBuilder;
import com.onlyoffice.integration.documentserver.util.file.FileUtility;
import com.onlyoffice.integration.documentserver.util.service.ServiceConverter;
import com.onlyoffice.integration.dto.DocRequest;
import com.onlyoffice.integration.entities.User;
import com.onlyoffice.integration.services.UserServices;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.awt.*;
import java.io.*;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Optional;

import com.aspose.words.Shape;


@RestController
public class DemoController {
    @Autowired
    private FileUtility fileUtility;
    @Autowired
    private DocumentManager documentManager;
    @Autowired
    private JwtManager jwtManager;
    @Autowired
    private FileStorageMutator storageMutator;
    @Autowired
    private FileStoragePathBuilder storagePathBuilder;
    @Autowired
    private UserServices userService;
    @Autowired
    private CallbackHandler callbackHandler;
    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private ServiceConverter serviceConverter;
    @Autowired
    private CallbackManager callbackManager;

    @PostMapping("/file/create")
    public void createFile(@RequestBody DocRequest request) {
        Boolean sampleData = false;
        if (request.getFileExt() != null) {
            try {
                Optional<User> user = userService.findUserById(Integer.parseInt(request.getUid()));  // find a user by their ID
                if (!user.isPresent()) {
                    // if the user with the specified ID doesn't exist, an error occurs
                    throw new RuntimeException("Could not fine any user with id = " + request.getUid());
                }
                String fileName = documentManager.createOutline(request.getFileExt(),
                        sampleData,
                        request.getUid(),
                        user.get().getName());  // create a demo document with the sample data
                if (fileName.isBlank() || fileName == null) {
                    throw new RuntimeException("You must have forgotten to add asset files");
                }
                //storageMutator.writeToFile(String pathName, String payload)
                return ;
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return ;
    }


    public void removeWaterMark() {
        FileInputStream fis = null;
        try {
            fis = new FileInputStream("待处理的Word文档.docx");
            XWPFDocument doc = new XWPFDocument(fis);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @GetMapping("/demo")
    public String run() {
        try {
            // 创建一个 Runtime 实例
            Runtime runtime = Runtime.getRuntime();

            // 运行一个命令行命令
            Process process = runtime.exec("cd /opt/backend; documentbuilder test.builder");

            //Process process1 = runtime.exec("documentbuilder test.builder");

            // 获取命令行输出
            int exitValue = process.waitFor();
            System.out.println("命令行执行结果：" + exitValue);

//            // 创建一个 ProcessBuilder 实例
//            ProcessBuilder processBuilder = new ProcessBuilder("ls", "-l");
//
//            // 设置工作目录（可选）
//            processBuilder.directory(new File("/path/to/directory"));
//
//            // 启动进程
//            Process process1 = processBuilder.start();
//
//            // 获取命令行输出
//            int exitValue1 = process.waitFor();
//            System.out.println("命令行执行结果11：" + exitValue);
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }

        return null;
    }

    @GetMapping("/createNew")
    public Document createDocument() {
        try {
            // 创建一个新的空白 Word 文档
            Document doc = new Document();

            // 添加一个段落到文档中
            Paragraph para = new Paragraph(doc);
            doc.getFirstSection().getBody().appendChild(para);

            // 添加文本到段落中
            Run run = new Run(doc, "Hello, World!");
            para.appendChild(run);

            // 保存文档
            doc.save("/Users/songyifan/testdoc/output.docx");

            System.out.println("Word 文件创建成功！");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @GetMapping("/combine")
    public Document combineDocument() {
        try {
            Document srcDoc = new Document("/Users/songyifan/testdoc/large/" + "new.docx");
            Document dstDoc = new Document("/Users/songyifan/testdoc/large/" + "test.docx");

            dstDoc.appendDocument(srcDoc, ImportFormatMode.KEEP_SOURCE_FORMATTING);
            dstDoc.save("/Users/songyifan/testdoc/large/" + "combine.docx");


//            Document srcDoc = new Document("/Users/songyifan/testdoc/" + "test1.docx");
//            Document dstDoc = new Document("/Users/songyifan/testdoc/" + "test2.docx");
//
//            // Append the source document to the destination document using no extra options.
//            dstDoc.appendDocument(srcDoc, ImportFormatMode.KEEP_SOURCE_FORMATTING);
//
//            dstDoc.save("/Users/songyifan/testdoc/" + "combine.docx");
//
//            Document doc = new Document("/Users/songyifan/testdoc/" + "combine.docx");
//
//
//            Shape watermark = new Shape(doc, ShapeType.TEXT_PLAIN_TEXT);
//            {
//                watermark.setName("Watermark");
//            }
//
//            watermark.getTextPath().setText("TEST");
//            watermark.getTextPath().setFontFamily("Arial");
//            watermark.setWidth(500.0);
//            watermark.setHeight(100.0);
//
//            // Text will be directed from the bottom-left to the top-right corner.
//            watermark.setRotation(-40);
//
//            // Remove the following two lines if you need a solid black text.
//            watermark.setFillColor(Color.GRAY);
//            watermark.setStrokeColor(Color.GRAY);
//
//            // Place the watermark in the page center.
//            watermark.setRelativeHorizontalPosition(RelativeHorizontalPosition.PAGE);
//            watermark.setRelativeVerticalPosition(RelativeVerticalPosition.PAGE);
//            watermark.setWrapType(WrapType.NONE);
//            watermark.setVerticalAlignment(VerticalAlignment.CENTER);
//            watermark.setHorizontalAlignment(HorizontalAlignment.CENTER);
//
//            // Create a new paragraph and append the watermark to this paragraph.
//            Paragraph watermarkPara = new Paragraph(doc);
//            watermarkPara.appendChild(watermark);
//
//            // Insert the watermark into all headers of each document section.
//            for (Section sect : (Iterable<Section>) doc.getSections()) {
//                // There could be up to three different headers in each section.
//                // Since we want the watermark to appear on all pages, insert it into all headers.
//                insertWatermarkIntoHeader(watermarkPara, sect, HeaderFooterType.HEADER_PRIMARY);
//                insertWatermarkIntoHeader(watermarkPara, sect, HeaderFooterType.HEADER_FIRST);
//                insertWatermarkIntoHeader(watermarkPara, sect, HeaderFooterType.HEADER_EVEN);
//            }
//
//            doc.save("/Users/songyifan/testdoc/" + "combine_water.docx");
//
//            for (HeaderFooter hf : (Iterable<HeaderFooter>) doc.getChildNodes(NodeType.HEADER_FOOTER, true))
//            {
//                for (Shape shape : (Iterable<Shape>) hf.getChildNodes(NodeType.SHAPE, true))
//                {
//
//                        shape.remove();
//                }
//            }
//            doc.save("/Users/songyifan/testdoc/" + "combine_remove.docx");
//
//            Document doc1 = new Document("/Users/songyifan/testdoc/" + "combine_remove.docx");
//            if(doc1.getWatermark().getType() == 2) {
//                doc1.getWatermark().remove();
//            }
//            doc1.save("/Users/songyifan/testdoc/" + "RemoveWatermark_out.docx");

            return null;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private void insertWatermarkIntoHeader(Paragraph watermarkPara, Section sect,
            /*HeaderFooterType*/int headerType) {
        HeaderFooter header = sect.getHeadersFooters().getByHeaderFooterType(headerType);

        if (header == null) {
            // There is no header of the specified type in the current section, so we need to create it.
            header = new HeaderFooter(sect.getDocument(), headerType);
            sect.getHeadersFooters().add(header);
        }

        // Insert a clone of the watermark into the header.
        header.appendChild(watermarkPara.deepClone(true));
    }


}
