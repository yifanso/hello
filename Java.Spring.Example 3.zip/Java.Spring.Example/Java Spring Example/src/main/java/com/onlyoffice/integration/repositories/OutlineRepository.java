package com.onlyoffice.integration.repositories;

import com.onlyoffice.integration.dto.Outline;
import com.onlyoffice.integration.entities.File;
import com.onlyoffice.integration.entities.OutlineFile;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface OutlineRepository extends JpaRepository<OutlineFile, Integer> {

    List<OutlineFile> findByCreateTime(String createTime);
}
