package com.onlyoffice.integration.services;

import com.onlyoffice.integration.dto.Outline;
import com.onlyoffice.integration.entities.File;
import com.onlyoffice.integration.entities.OutlineFile;
import com.onlyoffice.integration.repositories.FileRepository;
import com.onlyoffice.integration.repositories.OutlineRepository;
import org.hibernate.Criteria;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class FileService {

    @Autowired
    private FileRepository fileRepository;

    @Autowired
    private OutlineRepository outlineRepository;

    public Optional<File> findFileById(final Integer id) {
        return fileRepository.findById(id);
    }

    public File saveFile(File file) {
        file.setCreateUser("Test");
        return fileRepository.save(file);
    }

    public List<File> search(Outline outline) {
        return fileRepository.findByParentId(outline.getId());
    }

    public List<OutlineFile> searchRoot(String createTime) {
        return outlineRepository.findByCreateTime(createTime);
    }

}
