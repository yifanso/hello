package com.onlyoffice.integration.controllers;

import cn.hutool.core.io.resource.ResourceUtil;
import com.deepoove.poi.XWPFTemplate;
import com.deepoove.poi.data.*;
import com.onlyoffice.integration.dto.SheetMigration;
import com.onlyoffice.integration.utils.RestResponse;
import com.onlyoffice.integration.utils.SheetToPicture;
import org.apache.commons.collections4.list.TreeList;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.io.*;
import java.util.HashMap;
import java.util.List;

import static java.lang.Thread.sleep;


@RestController
@CrossOrigin("*")
public class SheetController {

    @Autowired
    private SheetToPicture sheetToPicture;

    @Value("${file.save.path}")
    private String path;

    @PostMapping("/cross/table1")
    public RestResponse sheetMigration(@RequestBody SheetMigration migration) throws Exception {
        RestResponse response = new RestResponse();
        try {
            //sheet转换为png格式图片
            String xslxPath = path + migration.getXlsFileName();
            String picName = migration.getXlsFileName().substring(0, migration.getXlsFileName().lastIndexOf('.')) + ".png";
            String name = path + picName;
            sheetToPicture.convert(xslxPath, name);
            //word中{{@**}}占位符替换为同名的图片
            String docxPath = path + migration.getDocxFileName();
            XWPFTemplate template = XWPFTemplate.compile(docxPath).render(
                    new HashMap<String, Object>() {
                        {
                            InputStream stream = ResourceUtil.getStream(name);
                            put(migration.getLable(), Pictures.ofStream(stream, PictureType.PNG).create());
                        }
                    }
            );
            sleep(1000);
            template.writeAndClose(new FileOutputStream(docxPath));

        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
        response.setCode(0);
        return response;


    }

    @PostMapping("/cross/table")
    public RestResponse sheet2Word(@RequestBody SheetMigration migration) throws Exception {

        RestResponse response = new RestResponse<>();
        // 获取 Word 模板所在路径
        String docPath = "/Users/songyifan/Desktop/Java.Spring.Example/Java Spring Example/documents/127.0.0.1/";
        String filepath = docPath + migration.getDocxFileName();
        // 通过 XWPFTemplate 编译文件并渲染数据到模板中
        XWPFTemplate template = XWPFTemplate.compile(filepath).render(
                new HashMap<String, Object>() {
                    {
                        FileInputStream inputStream = new FileInputStream(new File("/Users/songyifan/Desktop/Java.Spring.Example/Java Spring Example/documents/127.0.0.1/" + migration.getXlsFileName()));
                        Workbook workbook = new XSSFWorkbook(inputStream);  // 读取XLSX格式的文件
                        Sheet sheet = workbook.getSheetAt(0);

                        //RowRenderData tableHead = Rows.of(cell).center().bgColor("3672e5").create();

                        // 表格数据初始化
                        List<RowRenderData> renderDataList = new TreeList<>();
                        for (int i = 0; i < sheet.getPhysicalNumberOfRows(); i++) {
                            String[] rowData = new String[sheet.getRow(0).getPhysicalNumberOfCells()];
                            for (int j = 0; j < sheet.getRow(0).getPhysicalNumberOfCells(); j++) {
                                if (sheet.getRow(i) != null && sheet.getRow(i).getCell(j) != null) {
                                    String value = sheet.getRow(i).getCell(j).getStringCellValue();
                                    if (value != null) {
                                        rowData[j] = value;
                                    }
                                }
                            }
                            RowRenderData row = Rows.of(rowData).center().create();
                            renderDataList.add(row);
                        }
                        // 表格行构建
                        RowRenderData[] tableRows = new RowRenderData[sheet.getPhysicalNumberOfRows()];
                        // 添加数据行
                        for (int i = 0; i < renderDataList.size(); i++) {
                            tableRows[i] = renderDataList.get(i);
                        }
                        put(migration.getLable(), Tables.of(tableRows).center().create());
                    }
                }
        );
        try {
            // 将完成数据渲染的文档写出
            template.writeAndClose(new FileOutputStream(filepath));
        } catch (IOException e) {
            e.printStackTrace();
        }

        response.setCode(0);
        response.setMsg("success");
        return response;

    }

    private void pictureReplace() throws Exception {
        // 获取 Word 模板所在路径
        String filepath = "/Users/songyifan/Desktop/Java.Spring.Example/Java Spring Example/documents/172.20.10.11/11.docx";
        // 通过 XWPFTemplate 编译文件并渲染数据到模板中
        XWPFTemplate template = XWPFTemplate.compile(filepath).render(
                new HashMap<String, Object>() {
                    {
                        InputStream stream = ResourceUtil.getStream("/Users/songyifan/Desktop/Java.Spring.Example/Java Spring Example/documents/172.20.10.11/logo.jpg");
                        put("companyLogoUrl", Pictures.ofStream(stream, PictureType.PNG).create());
                    }
                }
        );
    }

}
