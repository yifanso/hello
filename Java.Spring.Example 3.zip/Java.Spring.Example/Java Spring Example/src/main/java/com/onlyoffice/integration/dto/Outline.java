package com.onlyoffice.integration.dto;

import lombok.Data;

import java.util.List;

@Data
public class Outline {
    List<String> outline;
    int id;
    String createTime;
    String name;
}
